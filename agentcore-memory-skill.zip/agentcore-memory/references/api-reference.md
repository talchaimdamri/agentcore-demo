# AgentCore Memory API Reference

## Table of Contents
1. [MemorySessionManager (Data Plane)](#memorysessionmanager-data-plane)
2. [MemoryManager (Control Plane)](#memorymanager-control-plane)
3. [Message Types](#message-types)
4. [Strategy Types](#strategy-types)

---

## MemorySessionManager (Data Plane)

```python
from bedrock_agentcore.memory import MemorySessionManager
```

### Constructor

```python
MemorySessionManager(
    memory_id: str,           # Required - from BEDROCK_AGENTCORE_MEMORY_ID
    region_name: str = None   # AWS region
)
```

### Session Management

```python
# Create session (returns MemorySession)
session = manager.create_memory_session(
    actor_id: str,            # Required
    session_id: str = None    # Optional - generates UUID if not provided
)

# List actors
actors = manager.list_actors()

# List sessions for actor
sessions = manager.list_actor_sessions(actor_id: str)
```

### STM Operations

```python
# Add conversation turns
event = manager.add_turns(
    actor_id: str,
    session_id: str,
    messages: List[ConversationalMessage | BlobMessage]
) -> dict

# Get last K turns
turns = manager.get_last_k_turns(
    actor_id: str,
    session_id: str,
    k: int = 10
) -> List[List[dict]]

# List events in session
events = manager.list_events(
    actorId: str,
    sessionId: str
)
```

### LTM Operations

```python
# Semantic search
memories = manager.search_long_term_memories(
    query: str,
    namespace_prefix: str,
    top_k: int = 10
) -> List[dict]

# List memory records
records = manager.list_long_term_memory_records(
    namespace_prefix: str,
    max_results: int = 20
)

# Get/delete specific record
record = manager.get_memory_record(record_id: str)
manager.delete_memory_record(record_id: str)

# Delete all in namespace
manager.delete_all_long_term_memories_in_namespace(namespace_prefix: str)
```

### LLM Integration

```python
# Process turn with automatic memory handling
memories, response, event = manager.process_turn_with_llm(
    actor_id: str,
    session_id: str,
    user_input: str,
    llm_callback: Callable[[str, List[dict]], str],
    retrieval_config: Dict[str, RetrievalConfig] = None
)

# Async version
memories, response, event = await manager.process_turn_with_llm_async(...)
```

### Branch Management

```python
# Fork conversation
branch_event = session.fork_conversation(
    root_event_id: str,
    branch_name: str,
    messages: List[ConversationalMessage]
)

# List branches
branches = session.list_branches()

# Get events from branch
events = session.list_events(branch_name: str)
```

---

## MemoryManager (Control Plane)

```python
from bedrock_agentcore_starter_toolkit.operations.memory.manager import MemoryManager
```

### Constructor

```python
MemoryManager(
    region_name: str = None,
    boto3_session: boto3.Session = None,
    boto_client_config: Config = None
)
```

### Memory Lifecycle

```python
# Create memory and wait for ACTIVE
memory = manager.create_memory_and_wait(
    name: str,
    strategies: List[Strategy] = None,
    description: str = None,
    event_expiry_days: int = 90,      # 1-365
    max_wait: int = 300,              # seconds
    poll_interval: int = 10           # seconds
)

# Get or create (idempotent)
memory = manager.get_or_create_memory(
    name: str,
    strategies: List[Strategy] = None,
    description: str = None
)

# Get memory
memory = manager.get_memory(memory_id: str)

# List memories
memories = manager.list_memories(max_results: int = 100)

# Delete memory
manager.delete_memory_and_wait(memory_id: str, max_wait: int = 300)

# Check status
status = manager.get_memory_status(memory_id: str)  # CREATING, ACTIVE, FAILED, DELETING
```

### Strategy Management

```python
# Add strategy
memory = manager.add_strategy_and_wait(
    memory_id: str,
    strategy: Strategy,
    max_wait: int = 300
)

# Update strategies
memory = manager.update_memory_strategies_and_wait(
    memory_id: str,
    add_strategies: List[Strategy] = None,
    modify_strategies: List[dict] = None,
    delete_strategy_ids: List[str] = None
)

# Delete strategy
memory = manager.delete_strategy(memory_id: str, strategy_id: str)

# Get strategies
strategies = manager.get_memory_strategies(memory_id: str)
```

---

## Message Types

```python
from bedrock_agentcore.memory.constants import ConversationalMessage, BlobMessage, MessageRole
```

### ConversationalMessage

```python
ConversationalMessage(
    text: str,
    role: MessageRole
)
```

### BlobMessage

```python
BlobMessage(
    data: dict   # Binary data as dict
)
```

### MessageRole

```python
MessageRole.USER       # User input
MessageRole.ASSISTANT  # Agent response
MessageRole.TOOL       # Tool/function results
MessageRole.OTHER      # Any other type
```

### RetrievalConfig

```python
from bedrock_agentcore.memory.constants import RetrievalConfig

RetrievalConfig(
    top_k: int = 10,           # 1-1000
    relevance_score: float = 0.2,  # 0.0-1.0
    strategy_id: str = None
)
```

---

## Strategy Types

```python
from bedrock_agentcore_starter_toolkit.operations.memory.models import (
    SemanticStrategy,
    SummaryStrategy,
    UserPreferenceStrategy,
    CustomSemanticStrategy,
    ExtractionConfig,
    ConsolidationConfig
)
```

### SemanticStrategy

Extract factual knowledge using vector embeddings.

```python
SemanticStrategy(
    name: str,
    description: str = None,
    namespaces: List[str] = ["/facts/{actorId}"]
)
```

### SummaryStrategy

Create session summaries.

```python
SummaryStrategy(
    name: str,
    description: str = None,
    namespaces: List[str] = ["/summaries/{actorId}/{sessionId}"]
)
```

### UserPreferenceStrategy

Extract user behavior patterns.

```python
UserPreferenceStrategy(
    name: str,
    description: str = None,
    namespaces: List[str] = ["/preferences/{actorId}"]
)
```

### CustomSemanticStrategy

Custom extraction with prompts.

```python
extraction_config = ExtractionConfig(
    append_to_prompt: str,
    model_id: str = "anthropic.claude-3-sonnet-20240229-v1:0"
)

consolidation_config = ConsolidationConfig(
    append_to_prompt: str,
    model_id: str = "anthropic.claude-3-haiku-20240307-v1:0"
)

CustomSemanticStrategy(
    name: str,
    description: str = None,
    extraction_config: ExtractionConfig = None,
    consolidation_config: ConsolidationConfig = None,
    namespaces: List[str] = None
)
```

### Namespace Template Variables

| Variable | Description |
|----------|-------------|
| `{actorId}` | Actor identifier |
| `{sessionId}` | Session identifier |
| `{strategyId}` | Strategy identifier |

```python
namespaces = [
    "global/shared",                   # Static
    "actor/{actorId}",                 # Per-actor
    "session/{actorId}/{sessionId}",   # Per-session
]
```

---

## Memory Data Structure

```python
{
    "id": str,              # Memory ID
    "arn": str,             # ARN
    "name": str,            # Memory name
    "status": str,          # CREATING, ACTIVE, FAILED, DELETING
    "eventExpiryDuration": int,  # Days (1-365)
    "createdAt": timestamp,
    "updatedAt": timestamp,
    "description": str,     # Optional
    "strategies": [...]     # List of strategies
}
```

## LTM Record Structure

```python
{
    "recordId": str,
    "content": {
        "text": str
    },
    "relevanceScore": float,  # 0.0-1.0
    "namespace": str,
    "timestamp": str
}
```

## STM Turn Structure

```python
[
    {
        "role": "USER",
        "content": {"text": "Hello"},
        "timestamp": "..."
    },
    {
        "role": "ASSISTANT",
        "content": {"text": "Hi!"},
        "timestamp": "..."
    }
]
```
