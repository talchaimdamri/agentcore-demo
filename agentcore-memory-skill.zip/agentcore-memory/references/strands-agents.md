# AgentCore Memory with Strands Agents

## Overview

Strands Agents SDK has built-in AgentCore Memory support via the `AgentCoreMemorySessionManager` session manager.

## Installation

```bash
pip install strands-agents strands-agents-tools
```

## Quick Integration

```python
from strands import Agent
from strands.models.bedrock import BedrockModel
from strands_tools import calculator
from strands.session_managers.agentcore_memory import AgentCoreMemorySessionManager

# Initialize session manager with existing memory
session_manager = AgentCoreMemorySessionManager(
    memory_id="your-memory-id",  # From BEDROCK_AGENTCORE_MEMORY_ID
    region_name="us-east-1"
)

# Create agent with memory
agent = Agent(
    model=BedrockModel("anthropic.claude-3-haiku-20240307-v1:0"),
    session_manager=session_manager,
    tools=[calculator],
    load_tools_from_directory=False
)

# Start conversation - session manager handles STM automatically
response = agent(
    "What is 2 + 2?",
    session_id="user-123-session-456"
)
```

## Session Manager Configuration

```python
from strands.session_managers.agentcore_memory import AgentCoreMemorySessionManager
import os

session_manager = AgentCoreMemorySessionManager(
    memory_id=os.environ["BEDROCK_AGENTCORE_MEMORY_ID"],
    region_name=os.environ.get("AWS_REGION", "us-east-1")
)
```

## LTM Search (Manual)

Strands handles STM automatically. For LTM search, access the underlying manager:

```python
# Access underlying MemorySessionManager for LTM search
manager = session_manager._memory_session_manager

memories = manager.search_long_term_memories(
    query="user preferences",
    namespace_prefix="/preferences/user-123",
    top_k=5
)

# Inject memories into system prompt
context = "\n".join([
    m.get('content', {}).get('text', '')
    for m in memories
    if m.get('relevanceScore', 0) > 0.3
])

agent = Agent(
    model=BedrockModel("anthropic.claude-3-haiku-20240307-v1:0"),
    session_manager=session_manager,
    system_prompt=f"You are a helpful assistant.\n\nRelevant memories:\n{context}"
)
```

## Complete Example

```python
import os
from strands import Agent
from strands.models.bedrock import BedrockModel
from strands.session_managers.agentcore_memory import AgentCoreMemorySessionManager

def create_memory_agent(actor_id: str, session_id: str):
    """Create Strands agent with AgentCore Memory."""

    # Initialize session manager
    session_manager = AgentCoreMemorySessionManager(
        memory_id=os.environ["BEDROCK_AGENTCORE_MEMORY_ID"],
        region_name=os.environ.get("AWS_REGION", "us-east-1")
    )

    # Search LTM for context
    manager = session_manager._memory_session_manager
    memories = manager.search_long_term_memories(
        query="user preferences and history",
        namespace_prefix=f"/facts/{actor_id}",
        top_k=5
    )

    context = ""
    if memories:
        facts = [m.get('content', {}).get('text', '') for m in memories if m.get('relevanceScore', 0) > 0.3]
        if facts:
            context = "\n\nKnown facts about this user:\n" + "\n".join(f"- {f}" for f in facts)

    # Create agent with memory context
    agent = Agent(
        model=BedrockModel("anthropic.claude-3-haiku-20240307-v1:0"),
        session_manager=session_manager,
        system_prompt=f"You are a helpful assistant.{context}"
    )

    return agent

# Usage
agent = create_memory_agent("user-123", "session-456")
response = agent("What do you remember about me?", session_id="session-456")
```

## Key Points

- **STM**: Handled automatically by `AgentCoreMemorySessionManager`
- **LTM**: Requires manual search via underlying `_memory_session_manager`
- **Session ID**: Pass to each `agent()` call for conversation continuity
- **Actor ID**: Derived from session_id by default, override via namespace patterns
