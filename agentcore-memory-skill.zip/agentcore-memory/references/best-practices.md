# AgentCore Memory Best Practices

## Table of Contents
1. [Memory Initialization](#memory-initialization)
2. [Session & Actor Management](#session--actor-management)
3. [STM Best Practices](#stm-best-practices)
4. [LTM Best Practices](#ltm-best-practices)
5. [Error Handling](#error-handling)
6. [Performance Optimization](#performance-optimization)
7. [Common Mistakes](#common-mistakes)

---

## Memory Initialization

### Use Lazy Initialization with Caching

```python
# GOOD: Cache at module level
_manager = None

def get_manager():
    global _manager
    if _manager is None:
        _manager = MemorySessionManager(
            memory_id=os.environ["BEDROCK_AGENTCORE_MEMORY_ID"],
            region_name=os.environ.get("AWS_REGION", "us-east-1")
        )
    return _manager

# BAD: New instance per request
def bad_handler(payload):
    manager = MemorySessionManager(...)  # Creates new client each time
```

### Use Environment Variables

```python
# GOOD: Use toolkit-injected variables
MEMORY_ID = os.environ.get("BEDROCK_AGENTCORE_MEMORY_ID")

# BAD: Hardcoded or get_or_create on every request
memory = memory_manager.get_or_create_memory(...)  # Creates new memory
```

---

## Session & Actor Management

### Consistent Session IDs

```python
# GOOD: Generate once in API, pass to agent
@app.post("/invoke")
async def invoke(req):
    session_id = req.session_id or str(uuid.uuid4())
    payload = {"prompt": req.prompt, "session_id": session_id}
    # ... invoke agent with consistent session_id

# BAD: Different session IDs in API vs agent
```

### Meaningful Actor IDs

```python
# GOOD: Tie to user identity
actor_id = f"user_{user.id}"
actor_id = f"tenant_{tenant_id}_user_{user_id}"  # Multi-tenant

# For anonymous users
actor_id = session_id  # Use session as actor

# BAD: Same actor for everyone
actor_id = "default"  # All users share memories!
```

---

## STM Best Practices

### Limit Context Size

```python
# GOOD: Limit turns and context size
MAX_STM_TURNS = 10
MAX_CONTEXT_CHARS = 4000

turns = manager.get_last_k_turns(actor_id, session_id, k=MAX_STM_TURNS)
stm_context = format_turns(turns)
if len(stm_context) > MAX_CONTEXT_CHARS:
    stm_context = stm_context[-MAX_CONTEXT_CHARS:]

# BAD: Unlimited context
turns = manager.get_last_k_turns(actor_id, session_id, k=100)  # Too many
```

### Store Complete Turns

```python
# GOOD: Store after getting response
response = await call_llm(prompt, context)
manager.add_turns(actor_id, session_id, [
    ConversationalMessage(prompt, MessageRole.USER),
    ConversationalMessage(response, MessageRole.ASSISTANT)
])

# BAD: Store before response (incomplete on failure)
manager.add_turns(actor_id, session_id, [
    ConversationalMessage(prompt, MessageRole.USER)
])
response = await call_llm(...)  # If fails, no assistant message
```

### Batch Messages

```python
# GOOD: Single call for full turn
messages = [
    ConversationalMessage(user_msg, MessageRole.USER),
    ConversationalMessage(tool_result, MessageRole.TOOL),
    ConversationalMessage(response, MessageRole.ASSISTANT)
]
manager.add_turns(actor_id, session_id, messages)

# BAD: Separate calls
manager.add_turns(..., [user_msg])
manager.add_turns(..., [tool_result])
manager.add_turns(..., [response])
```

---

## LTM Best Practices

### Filter by Relevance Score

```python
# GOOD: Filter low-relevance results
MIN_RELEVANCE = 0.3

memories = manager.search_long_term_memories(query, namespace, top_k=10)
relevant = [m for m in memories if m.get('relevanceScore', 0) >= MIN_RELEVANCE]

# BAD: Use all results
for memory in memories:  # Includes noise
    context += memory.get('content', {}).get('text', '')
```

### Organize Namespaces by Scope

```python
# GOOD: Clear namespace organization
NAMESPACES = {
    # Per-actor (persists across sessions)
    "preferences": "/preferences/{actorId}",
    "facts": "/facts/{actorId}",

    # Per-session (session-specific)
    "summaries": "/summaries/{actorId}/{sessionId}",

    # Global (shared)
    "knowledge": "/knowledge/global"
}

# BAD: Flat namespaces
namespace = "/memories"  # Everything in one place
```

### LTM is Asynchronous

```python
# Remember: LTM extraction takes time
# After storing a turn, LTM may not be immediately available

# Test strategy: Wait a minute after conversation before checking LTM
# Production: Design for eventual consistency
```

---

## Error Handling

### Graceful Degradation

```python
# GOOD: Continue without memory on failure
def handler(payload):
    stm = ""
    ltm = ""
    manager = None

    try:
        manager = get_manager()
        stm = get_stm(manager, actor_id, session_id)
        ltm = get_ltm(manager, actor_id, query)
    except Exception as e:
        logger.warning("Memory unavailable: %s", e)
        # Continue without memory

    response = await call_llm(prompt, stm, ltm)

    if manager:  # Only store if manager available
        try:
            store_turn(manager, actor_id, session_id, prompt, response)
        except Exception:
            pass  # Non-fatal

    return response

# BAD: Let memory failures crash agent
def bad_handler(payload):
    manager = get_manager()  # Crashes on failure
    stm = get_stm(...)       # Crashes on failure
```

### Specific Error Handling

```python
from botocore.exceptions import ClientError, NoCredentialsError

try:
    manager = MemorySessionManager(...)
    manager.add_turns(...)
except NoCredentialsError:
    logger.error("AWS credentials not configured")
except ClientError as e:
    code = e.response['Error']['Code']
    if code == 'ResourceNotFoundException':
        logger.error("Memory not found - check MEMORY_ID")
    elif code == 'ValidationException':
        logger.error("Invalid parameters")
    elif code == 'ThrottlingException':
        logger.warning("Throttled - implement retry")
```

---

## Performance Optimization

### Parallel Retrieval

```python
import asyncio

# GOOD: Retrieve STM and LTM in parallel
async def get_context(manager, actor_id, session_id, query):
    stm_task = asyncio.to_thread(
        manager.get_last_k_turns, actor_id, session_id, 10
    )
    ltm_task = asyncio.to_thread(
        manager.search_long_term_memories, query, f"/facts/{actor_id}", 5
    )

    stm, ltm = await asyncio.gather(stm_task, ltm_task)
    return stm, ltm

# BAD: Sequential retrieval
stm = manager.get_last_k_turns(...)  # Wait
ltm = manager.search_long_term_memories(...)  # Wait again
```

### Connection Reuse

```python
# GOOD: Reuse manager across requests
class Agent:
    def __init__(self):
        self.manager = MemorySessionManager(...)

    def handle(self, payload):
        # Reuses self.manager
        pass

# BAD: Create per request
def handle(payload):
    manager = MemorySessionManager(...)  # New connection
```

### Appropriate top_k Values

```python
# Balance relevance and performance
STM_K = 10      # Recent context
LTM_TOP_K = 5   # Relevant memories

# Avoid: top_k=100 (too slow, too much context)
```

---

## Common Mistakes

### Mistake 1: Creating Memory Per Request

```python
# WRONG: Creates new memory resource each time
memory = manager.get_or_create_memory(name="agent_memory", ...)
_memory_id = memory.get("id")

# RIGHT: Use environment variable from deployment
memory_id = os.environ["BEDROCK_AGENTCORE_MEMORY_ID"]
```

### Mistake 2: Different Session IDs

```python
# WRONG: Session ID changes between requests
session_id = str(uuid.uuid4())  # New every time!

# RIGHT: Persist and reuse session ID
session_id = request.session_id or create_new_session_id()
```

### Mistake 3: Ignoring Memory Failures

```python
# WRONG: No error handling
manager.add_turns(...)  # May fail silently

# RIGHT: Log failures but continue
try:
    manager.add_turns(...)
except Exception as e:
    logger.warning("Memory storage failed: %s", e)
```

### Mistake 4: Storing Before LLM Response

```python
# WRONG: Missing assistant message if LLM fails
manager.add_turns([user_message])
response = await llm(...)  # Might fail

# RIGHT: Store complete turn after response
response = await llm(...)
manager.add_turns([user_message, assistant_response])
```

### Mistake 5: Default Actor ID

```python
# WRONG: All users share memories
actor_id = "default"

# RIGHT: Unique per user
actor_id = f"user_{user_id}"
```

### Mistake 6: Too Much Context

```python
# WRONG: Overwhelming context window
turns = manager.get_last_k_turns(k=50)
memories = manager.search_long_term_memories(top_k=20)

# RIGHT: Reasonable limits
turns = manager.get_last_k_turns(k=10)
memories = manager.search_long_term_memories(top_k=5)
```

---

## Debugging Tips

### Enable Debug Logging

```python
import logging
logging.getLogger('bedrock_agentcore.memory').setLevel(logging.DEBUG)
```

### Verify Configuration

```python
def verify_config():
    print(f"MEMORY_ID: {os.environ.get('BEDROCK_AGENTCORE_MEMORY_ID', 'NOT SET')}")
    print(f"AWS_REGION: {os.environ.get('AWS_REGION', 'NOT SET')}")
```

### Check Memory Contents

```python
def debug_memory(manager, actor_id, session_id):
    print(f"=== Debug {actor_id}/{session_id} ===")

    turns = manager.get_last_k_turns(actor_id, session_id, 10)
    print(f"STM turns: {len(turns)}")

    actors = manager.list_actors()
    print(f"Total actors: {len(actors)}")
```
