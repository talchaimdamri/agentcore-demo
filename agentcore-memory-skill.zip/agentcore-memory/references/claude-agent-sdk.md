# AgentCore Memory with Claude Agent SDK

## Overview

Claude Agent SDK (claude-agent-sdk) provides a flexible agentic framework. Memory integration is done manually by retrieving context and storing turns.

## Installation

```bash
pip install claude-agent-sdk bedrock-agentcore bedrock-agentcore-starter-toolkit
```

## Architecture

```
┌─────────────────────────────────────┐
│         Your Handler                │
├─────────────────────────────────────┤
│  1. Get STM (conversation history)  │
│  2. Search LTM (relevant memories)  │
│  3. Inject into system_prompt       │
├─────────────────────────────────────┤
│         ClaudeSDKClient             │
│  - query() with enriched prompt     │
│  - receive_messages() loop          │
├─────────────────────────────────────┤
│  4. Store conversation turn         │
└─────────────────────────────────────┘
```

## Memory Helper Functions

```python
import os
import logging
from bedrock_agentcore.memory import MemorySessionManager
from bedrock_agentcore.memory.constants import ConversationalMessage, MessageRole

logger = logging.getLogger(__name__)

# Global cache for session manager
_memory_session_manager = None

def get_memory_session_manager() -> MemorySessionManager:
    """Lazy-initialize and cache the memory session manager."""
    global _memory_session_manager

    if _memory_session_manager is not None:
        return _memory_session_manager

    memory_id = os.environ.get("BEDROCK_AGENTCORE_MEMORY_ID")
    if not memory_id:
        raise ValueError("BEDROCK_AGENTCORE_MEMORY_ID not set")

    _memory_session_manager = MemorySessionManager(
        memory_id=memory_id,
        region_name=os.environ.get("AWS_REGION", "us-east-1")
    )
    return _memory_session_manager


def get_stm_context(manager: MemorySessionManager, actor_id: str, session_id: str, k: int = 10) -> str:
    """Retrieve STM (conversation history) formatted for system prompt."""
    try:
        turns = manager.get_last_k_turns(actor_id=actor_id, session_id=session_id, k=k)
        if not turns:
            return ""

        history = []
        for turn in turns:
            for msg in turn:
                role = msg.get('role', 'unknown')
                text = msg.get('content', {}).get('text', '')
                if text:
                    label = "User" if role.lower() in ['user', 'human'] else "Assistant"
                    history.append(f"{label}: {text}")

        if not history:
            return ""

        return "\n## CONVERSATION HISTORY:\n" + "\n".join(history) + "\n"

    except Exception as e:
        logger.warning("Failed to get STM: %s", e)
        return ""


def get_ltm_context(manager: MemorySessionManager, actor_id: str, query: str, top_k: int = 5) -> str:
    """Search LTM and format results for system prompt."""
    try:
        memories = manager.search_long_term_memories(
            query=query,
            namespace_prefix=f"/facts/{actor_id}",
            top_k=top_k
        )

        if not memories:
            return ""

        relevant = []
        for m in memories:
            text = m.get('content', {}).get('text', '')
            score = m.get('relevanceScore', 0)
            if text and score > 0.3:
                relevant.append(f"- {text}")

        if not relevant:
            return ""

        return "\n## RELEVANT MEMORIES:\n" + "\n".join(relevant) + "\n"

    except Exception as e:
        logger.warning("Failed to search LTM: %s", e)
        return ""


async def store_turn(manager: MemorySessionManager, actor_id: str, session_id: str, user_msg: str, assistant_msg: str):
    """Store conversation turn in STM."""
    try:
        manager.add_turns(
            actor_id=actor_id,
            session_id=session_id,
            messages=[
                ConversationalMessage(user_msg, MessageRole.USER),
                ConversationalMessage(assistant_msg, MessageRole.ASSISTANT)
            ]
        )
    except Exception as e:
        logger.warning("Failed to store turn: %s", e)
```

## Complete Agent Example

```python
import os
import json
from claude_agent_sdk import (
    ClaudeAgentOptions, ClaudeSDKClient,
    AssistantMessage, UserMessage, ResultMessage,
    TextBlock, ToolUseBlock, ToolResultBlock
)
from bedrock_agentcore.runtime import BedrockAgentCoreApp

app = BedrockAgentCoreApp()

@app.entrypoint
async def main(payload):
    prompt = payload["prompt"]
    session_id = payload.get("session_id", "")
    actor_id = payload.get("actor_id", session_id or "default")

    # Initialize memory context
    stm_context = ""
    ltm_context = ""
    memory_manager = None

    try:
        memory_manager = get_memory_session_manager()
        stm_context = get_stm_context(memory_manager, actor_id, session_id)
        ltm_context = get_ltm_context(memory_manager, actor_id, prompt)
    except Exception as e:
        logger.warning("Memory unavailable: %s", e)

    # Build enriched system prompt
    system_prompt = f"""You are a helpful assistant.
{stm_context}{ltm_context}
Use the context above to provide personalized responses."""

    options = ClaudeAgentOptions(
        model="anthropic.claude-3-haiku-20240307-v1:0",
        system_prompt=system_prompt,
        allowed_tools=["your_tools_here"]
    )

    responses = []
    async with ClaudeSDKClient(options=options) as client:
        await client.query(prompt)
        async for msg in client.receive_messages():
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock):
                        responses.append(block.text)
                        yield {"type": "text", "text": block.text}
            elif isinstance(msg, ResultMessage):
                break

    # Store conversation turn
    if memory_manager and responses:
        await store_turn(
            memory_manager, actor_id, session_id,
            prompt, "\n".join(responses)
        )

    yield {"type": "final", "response": "\n".join(responses)}

if __name__ == "__main__":
    app.run()
```

## Key Integration Points

| Step | Action | Code |
|------|--------|------|
| 1 | Initialize manager | `get_memory_session_manager()` |
| 2 | Get STM | `get_stm_context(manager, actor_id, session_id)` |
| 3 | Search LTM | `get_ltm_context(manager, actor_id, query)` |
| 4 | Inject context | Add to `system_prompt` in `ClaudeAgentOptions` |
| 5 | Store turn | `store_turn(manager, actor_id, session_id, user, assistant)` |

## Best Practices

1. **Cache manager** at module level, not per-request
2. **Graceful degradation** - continue without memory on failure
3. **Store after response** - ensures complete turn is saved
4. **Limit context size** - use `k=10` for STM, `top_k=5` for LTM
5. **Filter by relevance** - ignore LTM with `relevanceScore < 0.3`
