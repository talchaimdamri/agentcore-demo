# AgentCore Memory with BedrockAgentCoreApp

## Overview

Direct integration with `BedrockAgentCoreApp` runtime, using `MemorySessionManager` for data plane and optionally `MemoryManager` for control plane.

## Installation

```bash
pip install bedrock-agentcore bedrock-agentcore-starter-toolkit
```

## Two Libraries

| Library | Class | Purpose |
|---------|-------|---------|
| `bedrock_agentcore_starter_toolkit` | `MemoryManager` | **Control Plane** - Create/delete memory resources |
| `bedrock_agentcore` | `MemorySessionManager` | **Data Plane** - Store/retrieve data |

## Runtime Integration

### Environment Variables (Set by Toolkit)

```bash
BEDROCK_AGENTCORE_MEMORY_ID=your-memory-id
BEDROCK_AGENTCORE_MEMORY_NAME=your-memory-name
```

### Minimal Agent

```python
import os
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from bedrock_agentcore.memory import MemorySessionManager
from bedrock_agentcore.memory.constants import ConversationalMessage, MessageRole

app = BedrockAgentCoreApp()

# Lazy-initialized manager
_manager = None

def get_manager():
    global _manager
    if _manager is None:
        _manager = MemorySessionManager(
            memory_id=os.environ["BEDROCK_AGENTCORE_MEMORY_ID"],
            region_name=os.environ.get("AWS_REGION", "us-east-1")
        )
    return _manager

@app.entrypoint
async def handler(payload):
    prompt = payload["prompt"]
    session_id = payload.get("session_id", "")
    actor_id = payload.get("actor_id", session_id)

    manager = get_manager()

    # Get STM
    turns = manager.get_last_k_turns(actor_id, session_id, k=10)

    # Search LTM
    memories = manager.search_long_term_memories(
        query=prompt,
        namespace_prefix=f"/facts/{actor_id}",
        top_k=5
    )

    # Call LLM with context
    response = await call_your_llm(prompt, turns, memories)

    # Store turn
    manager.add_turns(
        actor_id=actor_id,
        session_id=session_id,
        messages=[
            ConversationalMessage(prompt, MessageRole.USER),
            ConversationalMessage(response, MessageRole.ASSISTANT)
        ]
    )

    return {"response": response}

if __name__ == "__main__":
    app.run()
```

## Using process_turn_with_llm

Built-in method that handles retrieval, LLM call, and storage:

```python
from bedrock_agentcore.memory.constants import RetrievalConfig

def llm_callback(user_input: str, memories: list) -> str:
    """Your LLM implementation."""
    context = "\n".join([
        m.get('content', {}).get('text', '')
        for m in memories
    ])
    # Call Bedrock, OpenAI, etc.
    return your_llm_call(user_input, context)

@app.entrypoint
async def handler(payload):
    manager = get_manager()
    session = manager.create_memory_session(
        actor_id=payload.get("actor_id", "default"),
        session_id=payload.get("session_id", "")
    )

    retrieval_config = {
        "facts/{actorId}": RetrievalConfig(top_k=5, relevance_score=0.3),
        "preferences/{actorId}": RetrievalConfig(top_k=3, relevance_score=0.5)
    }

    memories, response, event = session.process_turn_with_llm(
        user_input=payload["prompt"],
        llm_callback=llm_callback,
        retrieval_config=retrieval_config
    )

    return {"response": response}
```

## Session Object Pattern

Session-scoped operations avoid repeating actor_id/session_id:

```python
@app.entrypoint
async def handler(payload):
    manager = get_manager()

    # Create session - encapsulates actor_id and session_id
    session = manager.create_memory_session(
        actor_id=payload.get("actor_id", "default"),
        session_id=payload.get("session_id", "")
    )

    # No need to pass actor_id/session_id again
    events = session.list_events()

    session.add_turns([
        ConversationalMessage("Hello", MessageRole.USER),
        ConversationalMessage("Hi!", MessageRole.ASSISTANT)
    ])

    memories = session.search_long_term_memories(
        query="preferences",
        namespace_prefix="preferences/{actorId}",
        top_k=5
    )
```

## Creating Memory Resources (Control Plane)

Use toolkit's `MemoryManager` to create memory resources:

```python
from bedrock_agentcore_starter_toolkit.operations.memory.manager import MemoryManager
from bedrock_agentcore_starter_toolkit.operations.memory.models import (
    SemanticStrategy, SummaryStrategy, UserPreferenceStrategy
)

def create_memory():
    manager = MemoryManager(region_name="us-east-1")

    strategies = [
        SemanticStrategy(
            name="Facts",
            namespaces=["/facts/{actorId}"]
        ),
        UserPreferenceStrategy(
            name="Preferences",
            namespaces=["/preferences/{actorId}"]
        ),
        SummaryStrategy(
            name="Summaries",
            namespaces=["/summaries/{actorId}/{sessionId}"]
        )
    ]

    memory = manager.create_memory_and_wait(
        name="my_agent_memory",
        strategies=strategies,
        event_expiry_days=90,
        max_wait=300
    )

    print(f"Created: {memory['id']}")
    return memory
```

## Error Handling Pattern

```python
@app.entrypoint
async def handler(payload):
    stm_context = ""
    ltm_context = ""
    manager = None

    try:
        manager = get_manager()
        turns = manager.get_last_k_turns(actor_id, session_id, k=10)
        stm_context = format_turns(turns)

        memories = manager.search_long_term_memories(query, namespace, top_k=5)
        ltm_context = format_memories(memories)
    except Exception as e:
        logger.warning("Memory unavailable, continuing without context: %s", e)

    # Agent works even without memory
    response = await call_llm(prompt, stm_context, ltm_context)

    # Only store if manager available
    if manager:
        try:
            manager.add_turns(actor_id, session_id, messages)
        except Exception as e:
            logger.warning("Failed to store turn: %s", e)

    return {"response": response}
```

## IAM Permissions Required

```json
{
    "Effect": "Allow",
    "Action": [
        "bedrock-agentcore:CreateEvent",
        "bedrock-agentcore:GetEvent",
        "bedrock-agentcore:ListEvents",
        "bedrock-agentcore:RetrieveMemoryRecords",
        "bedrock-agentcore:ListMemoryRecords"
    ],
    "Resource": "arn:aws:bedrock-agentcore:${region}:${account}:memory/${memory_id}"
}
```
