---
name: agentcore-memory
description: Add memory capabilities (STM and LTM) to AWS Bedrock AgentCore agents. Use this skill when integrating conversation history (short-term memory) and persistent user memories (long-term memory) into agents built with Strands Agents, Claude Agent SDK, or BedrockAgentCoreApp. Triggers include requests to add memory, enable persistence, remember user context, or integrate STM/LTM.
---

# AgentCore Memory Integration

## Overview

AgentCore Memory is a fully managed AWS service that enables AI agents to remember past interactions. This skill guides integration of:
- **STM (Short-term Memory)**: Conversation history within a session (up to 8 hours)
- **LTM (Long-term Memory)**: Extracted facts, preferences, and summaries across sessions (up to 365 days)

## Framework Selection

| Framework | Reference | When to Use |
|-----------|-----------|-------------|
| Strands Agents | [strands-agents.md](references/strands-agents.md) | Built-in AgentCoreMemorySessionManager |
| Claude Agent SDK | [claude-agent-sdk.md](references/claude-agent-sdk.md) | Manual integration with ClaudeSDKClient |
| BedrockAgentCoreApp | [bedrock-runtime.md](references/bedrock-runtime.md) | Direct runtime integration |

## Quick Start

### 1. Environment Setup

```python
import os

# Set by toolkit during deployment
MEMORY_ID = os.environ.get("BEDROCK_AGENTCORE_MEMORY_ID")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
```

### 2. Initialize Session Manager

```python
from bedrock_agentcore.memory import MemorySessionManager

# Lazy-initialize and cache
_manager = None

def get_manager():
    global _manager
    if _manager is None:
        _manager = MemorySessionManager(
            memory_id=MEMORY_ID,
            region_name=AWS_REGION
        )
    return _manager
```

### 3. Retrieve Context

```python
# Get STM (conversation history)
turns = manager.get_last_k_turns(actor_id, session_id, k=10)

# Search LTM (relevant memories)
memories = manager.search_long_term_memories(
    query=user_prompt,
    namespace_prefix=f"/facts/{actor_id}",
    top_k=5
)
```

### 4. Inject into System Prompt

```python
system_prompt = f"""You are a helpful assistant.

## CONVERSATION HISTORY:
{format_turns(turns)}

## RELEVANT MEMORIES:
{format_memories(memories)}
"""
```

### 5. Store Conversation Turn

```python
from bedrock_agentcore.memory.constants import ConversationalMessage, MessageRole

# After LLM response
manager.add_turns(
    actor_id=actor_id,
    session_id=session_id,
    messages=[
        ConversationalMessage(user_prompt, MessageRole.USER),
        ConversationalMessage(response, MessageRole.ASSISTANT)
    ]
)
```

## Two Libraries

| Library | Class | Purpose |
|---------|-------|---------|
| `bedrock_agentcore` | `MemorySessionManager` | **Data Plane** - Store/retrieve conversations |
| `bedrock_agentcore_starter_toolkit` | `MemoryManager` | **Control Plane** - Create/manage memory resources |

## Critical Rules

1. **Use environment variable**: `BEDROCK_AGENTCORE_MEMORY_ID` is injected by toolkit during deployment
2. **Cache session manager**: Initialize once, reuse across requests
3. **Store after response**: Ensures complete turn is saved
4. **Graceful degradation**: Agent should work even if memory fails
5. **Unique actor IDs**: Use `user_{id}`, not `"default"`
6. **Limit context**: `k=10` for STM, `top_k=5` for LTM
7. **Filter by relevance**: Ignore LTM with `relevanceScore < 0.3`

## References

- [API Reference](references/api-reference.md) - Complete API for both libraries
- [Best Practices](references/best-practices.md) - Patterns and common mistakes
- [Strands Agents Integration](references/strands-agents.md)
- [Claude Agent SDK Integration](references/claude-agent-sdk.md)
- [BedrockAgentCoreApp Integration](references/bedrock-runtime.md)
